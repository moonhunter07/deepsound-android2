/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { DSPSettings, Preset, PresetId, AudioTrack, BudsInfo } from './types/audio';
import { PRESETS } from './constants/presets';
import { dspEngine } from './services/dspEngine';
import { getBuiltInDemoTracks } from './services/demoAudioGenerator';

import { Header } from './components/Header';
import { Visualizer } from './components/Visualizer';
import { DSPControls } from './components/DSPControls';
import { PresetsBar } from './components/PresetsBar';
import { BudsCard } from './components/BudsCard';
import { PlayerControls } from './components/PlayerControls';
import { TrackListModal } from './components/TrackListModal';
import { InstallGuideBanner } from './components/InstallGuideBanner';

export default function App() {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Tracks & Playback state
  const [tracks, setTracks] = useState<AudioTrack[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(0.9);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [loopMode, setLoopMode] = useState<'off' | 'all' | 'one'>('all');
  const [shuffle, setShuffle] = useState<boolean>(false);

  // DSP & Presets State
  const [currentPresetId, setCurrentPresetId] = useState<PresetId>('buds_master');
  const [settings, setSettings] = useState<DSPSettings>({
    ...PRESETS[0].settings,
    bypass: false,
  });

  // Samsung Buds4 Pro State
  const [budsInfo, setBudsInfo] = useState<BudsInfo>({
    model: 'Samsung Galaxy Buds4 Pro',
    connected: true,
    codec: 'SSC', // Samsung Seamless Codec 24-bit 96kHz
    sampleRate: '96 kHz',
    bitDepth: '24-bit',
    batteryLeft: 92,
    batteryRight: 95,
    batteryCase: 85,
    ancMode: 'anc',
    spatial360: true,
    gamingMode: false,
  });

  const [isLibraryOpen, setIsLibraryOpen] = useState<boolean>(false);

  // Initialize demo tracks on mount
  useEffect(() => {
    const demoList = getBuiltInDemoTracks();
    setTracks(demoList);
  }, []);

  const currentTrack = tracks[currentTrackIndex] || null;

  // Apply settings to DSP Engine whenever settings change
  useEffect(() => {
    dspEngine.applySettings(settings);
  }, [settings]);

  // Audio element event setup
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
    };

    const onPlay = () => {
      setIsPlaying(true);
    };

    const onPause = () => {
      setIsPlaying(false);
    };

    const onEnded = () => {
      if (loopMode === 'one') {
        audio.currentTime = 0;
        audio.play().catch(console.warn);
      } else {
        handleNextTrack();
      }
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
    };
  }, [currentTrackIndex, loopMode, tracks]);

  // Sync volume with audio element
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Change audio source when track changes
  useEffect(() => {
    if (audioRef.current && currentTrack) {
      const audio = audioRef.current;
      const wasPlaying = isPlaying;

      if (currentTrack.url) {
        audio.src = currentTrack.url;
        audio.load();

        if (wasPlaying) {
          audio.play().catch(console.warn);
        }
      }
    }
  }, [currentTrackIndex, tracks]);

  // Handle Play/Pause with DSP initialization on first user interaction
  const handlePlayPause = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (!audio.src && currentTrack?.url) {
      audio.src = currentTrack.url;
      audio.load();
    }

    try {
      // Connect to DSP Engine on first play
      await dspEngine.init(audio);
      await dspEngine.resume();

      if (audio.paused) {
        await audio.play();
      } else {
        audio.pause();
      }
    } catch (err) {
      console.warn('Playback start error:', err);
    }
  };

  const handleNextTrack = () => {
    if (tracks.length === 0) return;
    if (shuffle) {
      const nextIdx = Math.floor(Math.random() * tracks.length);
      setCurrentTrackIndex(nextIdx);
    } else {
      setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
    }
  };

  const handlePrevTrack = () => {
    if (tracks.length === 0) return;
    if (currentTime > 3 && audioRef.current) {
      // If played more than 3 seconds, restart current track
      audioRef.current.currentTime = 0;
    } else {
      setCurrentTrackIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
    }
  };

  const handleSeek = (time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const handleSelectTrack = async (track: AudioTrack) => {
    const idx = tracks.findIndex((t) => t.id === track.id);
    if (idx !== -1) {
      setCurrentTrackIndex(idx);
      setIsLibraryOpen(false);

      if (audioRef.current) {
        audioRef.current.src = track.url || '';
        audioRef.current.load();
        try {
          await dspEngine.init(audioRef.current);
          await dspEngine.resume();
          await audioRef.current.play();
        } catch (err) {
          console.warn('Playback error:', err);
        }
      }
    }
  };

  const handleAddFiles = (files: FileList) => {
    const newTracks: AudioTrack[] = [];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const url = URL.createObjectURL(file);
      newTracks.push({
        id: `local-${Date.now()}-${i}`,
        title: file.name.replace(/\.[^/.]+$/, ''),
        artist: 'Локальный файл',
        duration: 0,
        url,
        type: 'local',
        format: file.name.split('.').pop()?.toUpperCase() || 'AUDIO',
      });
    }

    setTracks((prev) => [...prev, ...newTracks]);
  };

  const handleRemoveTrack = (trackId: string) => {
    setTracks((prev) => prev.filter((t) => t.id !== trackId));
    if (currentTrack?.id === trackId && tracks.length > 1) {
      handleNextTrack();
    }
  };

  const handleSelectPreset = (preset: Preset) => {
    setCurrentPresetId(preset.id);
    setSettings((prev) => ({
      ...prev,
      ...preset.settings,
      bypass: false,
    }));
  };

  const handleResetSettings = () => {
    const neutral = PRESETS.find((p) => p.id === 'neutral');
    if (neutral) {
      handleSelectPreset(neutral);
    }
  };

  const handleToggleBypass = () => {
    setSettings((prev) => ({
      ...prev,
      bypass: !prev.bypass,
    }));
  };

  const handleUpdateBuds = (newInfo: Partial<BudsInfo>) => {
    setBudsInfo((prev) => {
      const updated = {
        ...prev,
        ...newInfo,
      };
      // Keep DSP settings spatial360 in sync if toggled from BudsCard
      if (newInfo.spatial360 !== undefined && newInfo.spatial360 !== settings.spatial360) {
        setSettings((s) => ({
          ...s,
          spatial360: !!newInfo.spatial360,
        }));
      }
      return updated;
    });
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col selection:bg-sky-500/30">
      {/* Hidden audio element bound to Web Audio DSP */}
      <audio
        ref={audioRef}
        preload="metadata"
        crossOrigin="anonymous"
      />

      {/* Header */}
      <Header
        bypass={settings.bypass}
        onToggleBypass={handleToggleBypass}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-3 sm:p-4 md:p-6 pb-32 space-y-4">
        {/* Android PWA Install Guide Banner */}
        <InstallGuideBanner />

        {/* Samsung Galaxy Buds4 Pro Card */}
        <BudsCard
          budsInfo={budsInfo}
          onUpdateBuds={handleUpdateBuds}
        />

        {/* Real-time Spectrum / Wave / Vector Scope Visualizer */}
        <Visualizer
          isPlaying={isPlaying}
          bypass={settings.bypass}
          limiterEnabled={settings.limiterEnabled}
          subBassLevel={settings.subBass}
        />

        {/* Quick Presets Bar */}
        <PresetsBar
          currentPresetId={currentPresetId}
          onSelectPreset={handleSelectPreset}
          disabled={settings.bypass}
        />

        {/* Primary DSP Controls (Sub Bass, Bass, Clarity, Treble, Stereo Width, Loudness, Limiter) */}
        <DSPControls
          settings={settings}
          onChange={(newSettings) => {
            setSettings(newSettings);
            if (newSettings.spatial360 !== budsInfo.spatial360) {
              setBudsInfo((b) => ({ ...b, spatial360: newSettings.spatial360 }));
            }
            setCurrentPresetId('custom');
          }}
          onReset={handleResetSettings}
          disabled={settings.bypass}
        />
      </main>

      {/* Fixed Bottom Player Controls Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-gradient-to-t from-[#060911] via-[#060911]/95 to-transparent pt-4 pb-3 px-3 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <PlayerControls
            currentTrack={currentTrack}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            volume={volume}
            isMuted={isMuted}
            loopMode={loopMode}
            shuffle={shuffle}
            onPlayPause={handlePlayPause}
            onNext={handleNextTrack}
            onPrevious={handlePrevTrack}
            onSeek={handleSeek}
            onVolumeChange={(v) => {
              setVolume(v);
              setIsMuted(false);
            }}
            onToggleMute={() => setIsMuted(!isMuted)}
            onToggleLoop={() => {
              if (loopMode === 'off') setLoopMode('all');
              else if (loopMode === 'all') setLoopMode('one');
              else setLoopMode('off');
            }}
            onToggleShuffle={() => setShuffle(!shuffle)}
            onOpenLibrary={() => setIsLibraryOpen(true)}
          />
        </div>
      </div>

      {/* Library / Track List Modal */}
      <TrackListModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        tracks={tracks}
        currentTrackId={currentTrack?.id || null}
        isPlaying={isPlaying}
        onSelectTrack={handleSelectTrack}
        onAddFiles={handleAddFiles}
        onRemoveTrack={handleRemoveTrack}
      />
    </div>
  );
}
