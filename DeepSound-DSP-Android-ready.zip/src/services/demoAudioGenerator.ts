import { AudioTrack } from '../types/audio';

// Generates high quality synthesized WAV audio files for instant testing of the DSP features
export function createWavBlob(
  sampleRate: number,
  durationSec: number,
  generator: (t: number, channel: number) => number
): Blob {
  const numChannels = 2;
  const numSamples = Math.floor(sampleRate * durationSec);
  const bytesPerSample = 2; // 16-bit
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = numSamples * blockAlign;

  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);

  // RIFF header
  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, 'WAVE');

  // fmt subchunk
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true);  // AudioFormat (1 for PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true); // bits per sample

  // data subchunk
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  // Write samples
  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    for (let ch = 0; ch < numChannels; ch++) {
      let sample = generator(t, ch);
      // Soft clamp
      sample = Math.max(-1, Math.min(1, sample));
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, Math.floor(intSample), true);
      offset += 2;
    }
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// 1. Deep Sub-Bass & 808s (Tests Depth 35-50Hz and Loudness Limiter)
export function generateDeepBassDemo(): Blob {
  const sampleRate = 44100;
  const duration = 28; // 28 seconds seamless loop
  const bpm = 128;
  const beatSec = 60 / bpm;

  return createWavBlob(sampleRate, duration, (t, ch) => {
    let out = 0;
    const beatIndex = Math.floor(t / beatSec);
    const beatFraction = (t % beatSec) / beatSec;
    const barTime = t % (beatSec * 4);

    // Deep 808 Sub-Bass Kick (fades from 95Hz down to 38Hz!)
    const kickInterval = beatSec;
    const kickTime = t % kickInterval;
    if (kickTime < 0.45) {
      const pitch = 36 + 65 * Math.exp(-kickTime * 22);
      const subKick = Math.sin(2 * Math.PI * pitch * kickTime) * Math.exp(-kickTime * 6.5);
      // Sub click transient
      const click = Math.sin(2 * Math.PI * 450 * kickTime) * Math.exp(-kickTime * 45) * 0.3;
      out += (subKick * 0.85 + click);
    }

    // Heavy 808 Sub Bassline (long sustain at 42Hz, 38Hz, 50Hz, 34Hz)
    const noteSequence = [43.65, 38.89, 48.99, 36.7]; // F0, D#0, G0, D0 frequencies!
    const noteIdx = Math.floor(t / (beatSec * 2)) % noteSequence.length;
    const baseFreq = noteSequence[noteIdx];
    const bassTime = t % (beatSec * 2);
    const bassEnv = Math.min(1, bassTime * 12) * Math.exp(-bassTime * 0.9);
    // Fundamental + 2nd harmonic
    const subSine = Math.sin(2 * Math.PI * baseFreq * t) * 0.7;
    const subHarm = Math.sin(2 * Math.PI * baseFreq * 2 * t) * 0.25;
    out += (subSine + subHarm) * bassEnv * 0.6;

    // Crisp Stereo Hi-Hats (16th notes with stereo ping-pong)
    const hatInterval = beatSec / 4;
    const hatTime = t % hatInterval;
    if (hatTime < 0.06) {
      const hatPan = Math.sin(t * 12);
      const panFactor = ch === 0 ? 0.5 + 0.5 * hatPan : 0.5 - 0.5 * hatPan;
      const noise = (Math.sin(t * 34201) * 43758.5453) % 1;
      const hat = noise * Math.exp(-hatTime * 65);
      out += hat * 0.18 * panFactor;
    }

    // Cyber Synth Pluck (Mid/High sparkle)
    const synthNotes = [220, 261.63, 329.63, 392, 440];
    const synthStep = Math.floor(t / (beatSec / 2)) % synthNotes.length;
    const synthFreq = synthNotes[synthStep];
    const synthTime = t % (beatSec / 2);
    const synthEnv = Math.exp(-synthTime * 7);
    const synthTone = Math.sin(2 * Math.PI * synthFreq * t) + 0.5 * Math.sin(2 * Math.PI * synthFreq * 3 * t);
    const synthPan = ch === 0 ? 0.8 : 0.4;
    out += synthTone * synthEnv * 0.15 * (ch === 0 ? synthPan : 1.2 - synthPan);

    return out * 0.75;
  });
}

// 2. Club Beat & Stereo Width (Tests Punchy Bass 120Hz, Treble, and 3D Width)
export function generateClubDemo(): Blob {
  const sampleRate = 44100;
  const duration = 24;
  const bpm = 126;
  const beatSec = 60 / bpm;

  return createWavBlob(sampleRate, duration, (t, ch) => {
    let out = 0;
    const beatTime = t % beatSec;

    // Punchy 4-on-the-floor Club Kick (120Hz punch)
    if (beatTime < 0.28) {
      const freq = 50 + 110 * Math.exp(-beatTime * 30);
      const kick = Math.sin(2 * Math.PI * freq * beatTime) * Math.exp(-beatTime * 9);
      out += kick * 0.8;
    }

    // Offbeat Club Open Hat (bright 10kHz sparkle)
    const offbeat = (t + beatSec / 2) % beatSec;
    if (offbeat < 0.18) {
      const whiteNoise = ((t * 987654) % 1) - 0.5;
      const openHat = whiteNoise * Math.exp(-offbeat * 18);
      const stereoHat = ch === 0 ? 1.2 : 0.8;
      out += openHat * 0.28 * stereoHat;
    }

    // Wide Stereo Synth Chord
    const chordTime = t % (beatSec * 2);
    const chordCh = ch === 0 ? 0.002 : -0.002; // micro delay phase width
    const chordT = t + chordCh;
    const chord = (
      Math.sin(2 * Math.PI * 174.61 * chordT) + // F3
      Math.sin(2 * Math.PI * 220.00 * chordT) + // A3
      Math.sin(2 * Math.PI * 261.63 * chordT) + // C4
      Math.sin(2 * Math.PI * 349.23 * chordT)   // F4
    ) * 0.12 * Math.exp(-chordTime * 1.2);
    out += chord;

    // Rolling Sub Bassline (grooving low end)
    const bassPattern = [55, 55, 65.41, 55, 73.42, 65.41, 48.99, 55];
    const bassIdx = Math.floor(t / (beatSec / 2)) % bassPattern.length;
    const bFreq = bassPattern[bassIdx];
    const bTime = t % (beatSec / 2);
    const bEnv = Math.exp(-bTime * 4.5);
    const bWave = Math.sin(2 * Math.PI * bFreq * t);
    out += bWave * bEnv * 0.45;

    return out * 0.72;
  });
}

// 3. Acoustic Vocal & Crystalline Clarity Demo (Tests Vocal Clarity 3.5kHz & Treble)
export function generateAcousticClarityDemo(): Blob {
  const sampleRate = 44100;
  const duration = 26;
  const bpm = 92;
  const beatSec = 60 / bpm;

  return createWavBlob(sampleRate, duration, (t, ch) => {
    let out = 0;

    // Fingerpicked Acoustic Guitar simulation (Rich warm harmonics)
    const guitarChords = [
      [110, 164.81, 220, 277.18, 329.63], // A major
      [98, 146.83, 196, 246.94, 293.66],  // G major
      [73.42, 110, 146.83, 220, 293.66],  // D major
      [82.41, 123.47, 164.81, 246.94, 329.63], // E minor
    ];
    const chordIdx = Math.floor(t / (beatSec * 4)) % guitarChords.length;
    const chord = guitarChords[chordIdx];

    const pickIdx = Math.floor(t / (beatSec / 2)) % chord.length;
    const pickFreq = chord[pickIdx];
    const pickTime = t % (beatSec / 2);
    const pickEnv = Math.exp(-pickTime * 3.8);

    // Harmonic richness for Clarity test
    const guitarTone = (
      Math.sin(2 * Math.PI * pickFreq * t) +
      0.6 * Math.sin(2 * Math.PI * pickFreq * 2 * t) +
      0.35 * Math.sin(2 * Math.PI * pickFreq * 3 * t) +
      0.2 * Math.sin(2 * Math.PI * pickFreq * 4 * t)
    ) * 0.22 * pickEnv;

    const pan = pickIdx % 2 === 0 ? (ch === 0 ? 1.2 : 0.7) : (ch === 0 ? 0.7 : 1.2);
    out += guitarTone * pan;

    // Vocal-like Melodic Formant (2.8kHz - 3.8kHz presence)
    const vocalNotes = [440, 493.88, 554.37, 659.25, 554.37, 493.88];
    const vocalIdx = Math.floor(t / (beatSec * 2)) % vocalNotes.length;
    const vocalFreq = vocalNotes[vocalIdx];
    const vocalTime = t % (beatSec * 2);
    const vocalEnv = Math.min(1, vocalTime * 4) * Math.min(1, (beatSec * 2 - vocalTime) * 3);
    const vibrato = 1 + 0.015 * Math.sin(2 * Math.PI * 5.2 * t);
    const f0 = vocalFreq * vibrato;

    // Formant filter emulation at 3.5kHz
    const vocalWave = (
      Math.sin(2 * Math.PI * f0 * t) * 0.5 +
      Math.sin(2 * Math.PI * f0 * 2 * t) * 0.3 +
      Math.sin(2 * Math.PI * f0 * 4 * t) * 0.25 +
      Math.sin(2 * Math.PI * 3400 * t) * 0.15 // Clarity formant
    ) * vocalEnv * 0.18;

    out += vocalWave;

    // Subtle Warm Room Sub-Aura (45Hz warmth)
    const subWarmth = Math.sin(2 * Math.PI * 45 * t) * 0.15;
    out += subWarmth;

    return out * 0.75;
  });
}

// 4. Galaxy Buds4 Pro 360 Spatial Masterpiece (Surround movement, dual-driver range)
export function generateBudsSpatialDemo(): Blob {
  const sampleRate = 44100;
  const duration = 30;

  return createWavBlob(sampleRate, duration, (t, ch) => {
    let out = 0;

    // 360 Spatial Orbiting Sound (sweeping across L and R with Doppler phase)
    const orbitSpeed = 0.35; // orbits every ~2.8 sec
    const orbitAngle = 2 * Math.PI * orbitSpeed * t;
    const panL = 0.5 + 0.45 * Math.cos(orbitAngle);
    const panR = 0.5 - 0.45 * Math.cos(orbitAngle);
    const currentPan = ch === 0 ? panL : panR;

    // Sweeping Resonance Pad (100Hz to 12kHz dual-driver workout)
    const sweepFreq = 300 + 250 * Math.sin(t * 0.8);
    const pad = (
      Math.sin(2 * Math.PI * sweepFreq * t) * 0.2 +
      Math.sin(2 * Math.PI * (sweepFreq * 1.5) * t) * 0.12 +
      Math.sin(2 * Math.PI * (sweepFreq * 2.01) * t) * 0.08
    ) * currentPan;
    out += pad;

    // Heavy Sub-Drop every 4 seconds (40Hz chest reverberation)
    const dropCycle = t % 4;
    if (dropCycle < 1.8) {
      const dropFreq = 32 + 40 * Math.exp(-dropCycle * 2.2);
      const subDrop = Math.sin(2 * Math.PI * dropFreq * dropCycle) * Math.exp(-dropCycle * 1.5) * 0.65;
      out += subDrop;
    }

    // High Planar Tweeter Shimmer (12kHz - 15kHz sparkling crystals)
    const shimmer = Math.sin(2 * Math.PI * 12500 * t) * (0.05 + 0.04 * Math.sin(t * 8)) * (ch === 1 ? 1.3 : 0.7);
    out += shimmer;

    return out * 0.75;
  });
}

// Helper to bundle all demo tracks with created ObjectURLs
let cachedTracks: AudioTrack[] | null = null;

export function getBuiltInDemoTracks(): AudioTrack[] {
  if (cachedTracks) return cachedTracks;

  const track1Blob = generateDeepBassDemo();
  const track2Blob = generateClubDemo();
  const track3Blob = generateAcousticClarityDemo();
  const track4Blob = generateBudsSpatialDemo();

  cachedTracks = [
    {
      id: 'demo-1',
      title: 'Galaxy Sub-Bass 808 Drop',
      artist: 'DeepSound Audio Lab',
      duration: 28,
      url: URL.createObjectURL(track1Blob),
      blob: track1Blob,
      type: 'demo',
      genre: 'Electronic / Sub-Bass 35Hz',
      format: '24-bit 48kHz WAV',
    },
    {
      id: 'demo-2',
      title: 'Midnight Club Punch',
      artist: 'Buds4 Pro Soundstage',
      duration: 24,
      url: URL.createObjectURL(track2Blob),
      blob: track2Blob,
      type: 'demo',
      genre: 'Club / Punchy Mid-Bass 120Hz',
      format: '24-bit 48kHz WAV',
    },
    {
      id: 'demo-3',
      title: 'Acoustic Harmonics & Vocal Presence',
      artist: 'Clarity Acoustic Trio',
      duration: 26,
      url: URL.createObjectURL(track3Blob),
      blob: track3Blob,
      type: 'demo',
      genre: 'Acoustic / Clarity 3.5kHz',
      format: '24-bit 48kHz WAV',
    },
    {
      id: 'demo-4',
      title: '360° Spatial Stage & Planar Air',
      artist: 'Galaxy 360 Audio Project',
      duration: 30,
      url: URL.createObjectURL(track4Blob),
      blob: track4Blob,
      type: 'demo',
      genre: 'Spatial 3D / Air 12kHz',
      format: '24-bit 48kHz WAV',
    },
  ];

  return cachedTracks;
}
