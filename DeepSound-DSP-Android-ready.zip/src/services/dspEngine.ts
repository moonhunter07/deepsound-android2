import { DSPSettings } from '../types/audio';

export class DSPEngine {
  private ctx: AudioContext | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private bufferSourceNode: AudioBufferSourceNode | null = null;
  private audioElement: HTMLAudioElement | null = null;

  // Nodes
  private inputGain: GainNode | null = null;
  private dryGain: GainNode | null = null;
  private wetGain: GainNode | null = null;

  // Equalizer & Exciter Nodes
  private subBassFilter: BiquadFilterNode | null = null;
  private subHarmonicsFilter: BiquadFilterNode | null = null;
  private bassFilter: BiquadFilterNode | null = null;
  private clarityFilter: BiquadFilterNode | null = null;
  private trebleFilter: BiquadFilterNode | null = null;

  // Loudness & Saturation
  private loudnessPreGain: GainNode | null = null;
  private waveshaper: WaveShaperNode | null = null;

  // Stereo Widening (Mid-Side Matrix)
  private splitter: ChannelSplitterNode | null = null;
  private merger: ChannelMergerNode | null = null;
  private midGain: GainNode | null = null;
  private sideGainL: GainNode | null = null;
  private sideGainR: GainNode | null = null;

  // Spatial 360 HRTF Binaural Panning Nodes (Virtual Surround for Galaxy Buds4 Pro)
  private spatialSplitter: ChannelSplitterNode | null = null;
  private pannerL: PannerNode | null = null;
  private pannerR: PannerNode | null = null;
  private spatialDryGain: GainNode | null = null;
  private spatialWetGain: GainNode | null = null;
  private spatialMerger: GainNode | null = null;

  // Limiter / Anti-clipping
  private limiter: DynamicsCompressorNode | null = null;
  private masterOutputGain: GainNode | null = null;

  // Analysers
  public analyser: AnalyserNode | null = null;
  public stereoAnalyserL: AnalyserNode | null = null;
  public stereoAnalyserR: AnalyserNode | null = null;

  private currentSettings: DSPSettings = {
    subBass: 75,
    bass: 65,
    clarity: 60,
    treble: 70,
    stereoWidth: 70,
    spatial360: true,
    loudness: 50,
    limiterEnabled: true,
    bypass: false,
  };

  private isInitialized = false;

  constructor() {
    // Lazy init on first user touch/playback
  }

  public async init(audioEl: HTMLAudioElement): Promise<void> {
    if (this.isInitialized && this.ctx) {
      if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }
      return;
    }

    try {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtxClass({
        latencyHint: 'playback',
        sampleRate: 48000,
      });

      this.audioElement = audioEl;
      this.sourceNode = this.ctx.createMediaElementSource(audioEl);

      this.buildDSPGraph();
      this.applySettings(this.currentSettings);
      this.isInitialized = true;

      if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }
    } catch (err) {
      console.warn('DSP Engine initialization deferred or error:', err);
    }
  }

  private buildDSPGraph(): void {
    if (!this.ctx || !this.sourceNode) return;
    const ctx = this.ctx;

    // 1. Input Gain
    this.inputGain = ctx.createGain();
    this.dryGain = ctx.createGain();
    this.wetGain = ctx.createGain();

    // 2. Filters
    // Sub-bass shelf at 45Hz
    this.subBassFilter = ctx.createBiquadFilter();
    this.subBassFilter.type = 'lowshelf';
    this.subBassFilter.frequency.value = 45;

    // Sub-harmonics peak at 36Hz Q=1.4 for Buds4 Pro 11mm woofer punch
    this.subHarmonicsFilter = ctx.createBiquadFilter();
    this.subHarmonicsFilter.type = 'peaking';
    this.subHarmonicsFilter.frequency.value = 36;
    this.subHarmonicsFilter.Q.value = 1.4;

    // Mid-bass peak at 120Hz Q=1.1
    this.bassFilter = ctx.createBiquadFilter();
    this.bassFilter.type = 'peaking';
    this.bassFilter.frequency.value = 120;
    this.bassFilter.Q.value = 1.1;

    // Clarity peak at 3600Hz Q=1.2 for vocal presence
    this.clarityFilter = ctx.createBiquadFilter();
    this.clarityFilter.type = 'peaking';
    this.clarityFilter.frequency.value = 3600;
    this.clarityFilter.Q.value = 1.2;

    // Treble shelf at 9500Hz for planar micro-dynamics
    this.trebleFilter = ctx.createBiquadFilter();
    this.trebleFilter.type = 'highshelf';
    this.trebleFilter.frequency.value = 9500;

    // 3. Loudness Pre-Gain & Soft-Clipper Saturation
    this.loudnessPreGain = ctx.createGain();
    this.waveshaper = ctx.createWaveShaper();
    this.waveshaper.curve = this.createSoftClipperCurve(4096) as Float32Array<ArrayBuffer>;
    this.waveshaper.oversample = '2x';

    // 4. Mid-Side Stereo Widener
    this.splitter = ctx.createChannelSplitter(2);
    this.merger = ctx.createChannelMerger(2);

    // Summing nodes for M/S
    // Mid = (L + R) * 0.5
    // Side = (L - R) * 0.5 * width
    this.midGain = ctx.createGain();
    this.sideGainL = ctx.createGain();
    this.sideGainR = ctx.createGain();

    // 4b. Web Audio HRTF Binaural Spatial 360 Engine (Virtual Surround for Buds4 Pro)
    // AudioListener orientation (facing forward along -Z axis)
    if (ctx.listener.forwardX) {
      ctx.listener.forwardX.setValueAtTime(0, ctx.currentTime);
      ctx.listener.forwardY.setValueAtTime(0, ctx.currentTime);
      ctx.listener.forwardZ.setValueAtTime(-1, ctx.currentTime);
      ctx.listener.upX.setValueAtTime(0, ctx.currentTime);
      ctx.listener.upY.setValueAtTime(1, ctx.currentTime);
      ctx.listener.upZ.setValueAtTime(0, ctx.currentTime);
    }

    // Split stereo output into Left & Right discrete feeds for HRTF virtual speaker simulation
    this.spatialSplitter = ctx.createChannelSplitter(2);

    // Left Virtual Speaker (placed at ~35° left, slightly forward and eye-level)
    this.pannerL = new PannerNode(ctx, {
      panningModel: 'HRTF',
      distanceModel: 'inverse',
      positionX: -1.7,
      positionY: 0.15,
      positionZ: -1.2,
      orientationX: 1,
      orientationY: 0,
      orientationZ: 0,
      refDistance: 1,
      maxDistance: 10000,
      rolloffFactor: 1,
      coneInnerAngle: 360,
    });

    // Right Virtual Speaker (placed at ~35° right, slightly forward and eye-level)
    this.pannerR = new PannerNode(ctx, {
      panningModel: 'HRTF',
      distanceModel: 'inverse',
      positionX: 1.7,
      positionY: 0.15,
      positionZ: -1.2,
      orientationX: -1,
      orientationY: 0,
      orientationZ: 0,
      refDistance: 1,
      maxDistance: 10000,
      rolloffFactor: 1,
      coneInnerAngle: 360,
    });

    // Spatial Dry/Wet Crossfade
    this.spatialDryGain = ctx.createGain();
    this.spatialWetGain = ctx.createGain();
    this.spatialMerger = ctx.createGain();

    // 5. Brickwall Limiter (anti-clipping protection)
    this.limiter = ctx.createDynamicsCompressor();
    this.limiter.threshold.value = -1.2; // dB
    this.limiter.knee.value = 2.0;       // soft knee
    this.limiter.ratio.value = 20.0;     // limiting
    this.limiter.attack.value = 0.002;   // 2ms fast transient clamp
    this.limiter.release.value = 0.06;   // 60ms smooth recovery

    // 6. Master Output Gain
    this.masterOutputGain = ctx.createGain();
    this.masterOutputGain.gain.value = 1.0;

    // 7. Analysers
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 1024;
    this.analyser.smoothingTimeConstant = 0.82;

    this.stereoAnalyserL = ctx.createAnalyser();
    this.stereoAnalyserL.fftSize = 512;
    this.stereoAnalyserR = ctx.createAnalyser();
    this.stereoAnalyserR.fftSize = 512;

    // ---- Connections ----
    // Source -> InputGain
    this.sourceNode.connect(this.inputGain);

    // Bypass Dry Path
    this.inputGain.connect(this.dryGain);
    this.dryGain.connect(this.masterOutputGain);

    // Wet DSP Chain:
    // InputGain -> SubBass -> SubHarmonics -> Bass -> Clarity -> Treble -> LoudnessPreGain -> WaveShaper
    this.inputGain.connect(this.wetGain);
    this.wetGain.connect(this.subBassFilter);
    this.subBassFilter.connect(this.subHarmonicsFilter);
    this.subHarmonicsFilter.connect(this.bassFilter);
    this.bassFilter.connect(this.clarityFilter);
    this.clarityFilter.connect(this.trebleFilter);
    this.trebleFilter.connect(this.loudnessPreGain);
    this.loudnessPreGain.connect(this.waveshaper);

    // WaveShaper -> Stereo Widener (Mid-Side matrix)
    this.waveshaper.connect(this.splitter);

    // Mid path: (L+R) * 0.5 sent equally to L and R of merger
    this.splitter.connect(this.midGain, 0); // L
    this.splitter.connect(this.midGain, 1); // R
    this.midGain.connect(this.merger, 0, 0); // into L
    this.midGain.connect(this.merger, 0, 1); // into R

    // Side path:
    // Left side: +0.5 * width
    this.splitter.connect(this.sideGainL, 0);
    this.sideGainL.connect(this.merger, 0, 0);

    // Right side: -0.5 * width (inverted phase)
    this.splitter.connect(this.sideGainR, 1);
    this.sideGainR.connect(this.merger, 0, 1);

    // Merger feeds into both Spatial 360 HRTF wet path and direct dry path
    // Direct path (when Spatial 360 is OFF)
    this.merger.connect(this.spatialDryGain);
    this.spatialDryGain.connect(this.spatialMerger);

    // HRTF Spatial 360 path (when Spatial 360 is ON)
    this.merger.connect(this.spatialSplitter);
    this.spatialSplitter.connect(this.pannerL, 0); // Left channel to Left HRTF Panner
    this.spatialSplitter.connect(this.pannerR, 1); // Right channel to Right HRTF Panner

    this.pannerL.connect(this.spatialWetGain);
    this.pannerR.connect(this.spatialWetGain);
    this.spatialWetGain.connect(this.spatialMerger);

    // spatialMerger -> Limiter
    this.spatialMerger.connect(this.limiter);
    this.limiter.connect(this.masterOutputGain);

    // Master Output -> Analysers and Destination
    this.masterOutputGain.connect(this.analyser);
    this.analyser.connect(ctx.destination);

    // Also tap left and right for stereo vector scope
    const stereoSplit = ctx.createChannelSplitter(2);
    this.masterOutputGain.connect(stereoSplit);
    stereoSplit.connect(this.stereoAnalyserL, 0);
    stereoSplit.connect(this.stereoAnalyserR, 1);
  }

  // Smooth hyperbolic tangent soft-knee curve: prevents harsh digital clipping while boosting volume
  private createSoftClipperCurve(samples: number): Float32Array {
    const curve = new Float32Array(samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < samples; ++i) {
      const x = (i * 2) / samples - 1;
      // Hyperbolic tangent / soft saturation algorithm
      curve[i] = Math.tanh(x * 1.4) / Math.tanh(1.4);
    }
    return curve;
  }

  public applySettings(settings: DSPSettings): void {
    this.currentSettings = { ...settings };
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    const ramp = 0.04; // 40ms smooth parameter ramp

    const isBypass = settings.bypass;

    // Handle Dry/Wet routing
    if (this.dryGain && this.wetGain) {
      if (isBypass) {
        this.dryGain.gain.setTargetAtTime(1.0, now, ramp);
        this.wetGain.gain.setTargetAtTime(0.0, now, ramp);
      } else {
        this.dryGain.gain.setTargetAtTime(0.0, now, ramp);
        this.wetGain.gain.setTargetAtTime(1.0, now, ramp);
      }
    }

    if (isBypass) {
      return;
    }

    // Sub Bass Depth: 0% -> 0dB, 100% -> +16dB low-shelf + +8dB sub-harmonic peak
    const subFactor = settings.subBass / 100;
    if (this.subBassFilter) {
      const subDb = subFactor * 16.5; // up to +16.5dB deep sub-bass
      this.subBassFilter.gain.setTargetAtTime(subDb, now, ramp);
    }
    if (this.subHarmonicsFilter) {
      const harmDb = subFactor * 9.0; // sub-bass excitation peak at 36Hz
      this.subHarmonicsFilter.gain.setTargetAtTime(harmDb, now, ramp);
    }

    // Bass: 0% -> -3dB, 50% -> +5dB, 100% -> +14dB
    const bassFactor = settings.bass / 100;
    if (this.bassFilter) {
      const bassDb = (bassFactor - 0.2) * 15.0; // punch at 120Hz
      this.bassFilter.gain.setTargetAtTime(bassDb, now, ramp);
    }

    // Clarity: 0% -> 0dB, 100% -> +11dB vocal definition at 3.6kHz
    const clarityFactor = settings.clarity / 100;
    if (this.clarityFilter) {
      const clarityDb = clarityFactor * 11.5;
      this.clarityFilter.gain.setTargetAtTime(clarityDb, now, ramp);
    }

    // Treble: 0% -> 0dB, 100% -> +12.5dB planar sparkle at 9.5kHz
    const trebleFactor = settings.treble / 100;
    if (this.trebleFilter) {
      const trebleDb = trebleFactor * 12.5;
      this.trebleFilter.gain.setTargetAtTime(trebleDb, now, ramp);
    }

    // Loudness booster: 0% -> 1.0x gain (+0dB), 100% -> 2.6x gain (+8.3dB)
    const loudFactor = settings.loudness / 100;
    if (this.loudnessPreGain) {
      const preGain = 1.0 + loudFactor * 1.6;
      this.loudnessPreGain.gain.setTargetAtTime(preGain, now, ramp);
    }

    // Stereo Width:
    // 0% -> Mono (width = 0)
    // 50% -> Normal Stereo (width = 1.0)
    // 100% -> 3D Holographic Stage (width = 2.2)
    const widthFactor = (settings.stereoWidth / 50); // 0 to 2.0
    if (this.midGain && this.sideGainL && this.sideGainR) {
      // mid = 0.5
      this.midGain.gain.setTargetAtTime(0.5, now, ramp);
      // side = 0.5 * widthFactor
      this.sideGainL.gain.setTargetAtTime(0.5 * widthFactor, now, ramp);
      this.sideGainR.gain.setTargetAtTime(-0.5 * widthFactor, now, ramp);
    }

    // Spatial 360 HRTF Virtual Surround Panning Crossfade
    if (this.spatialDryGain && this.spatialWetGain) {
      if (settings.spatial360) {
        // Spatial 360 enabled: route through HRTF binaural virtual surround
        this.spatialDryGain.gain.setTargetAtTime(0.0, now, ramp);
        // Gain compensation for inverse distance rolloff so volume stays consistent
        this.spatialWetGain.gain.setTargetAtTime(1.85, now, ramp);
      } else {
        // Spatial 360 disabled: route pure direct stereo
        this.spatialDryGain.gain.setTargetAtTime(1.0, now, ramp);
        this.spatialWetGain.gain.setTargetAtTime(0.0, now, ramp);
      }
    }

    // Limiter:
    if (this.limiter) {
      if (settings.limiterEnabled) {
        this.limiter.threshold.setTargetAtTime(-1.2, now, ramp);
        this.limiter.ratio.setTargetAtTime(20.0, now, ramp);
      } else {
        // Disabling limiter opens threshold to 0dB and ratio to 1.0 (no compression)
        this.limiter.threshold.setTargetAtTime(0.0, now, ramp);
        this.limiter.ratio.setTargetAtTime(1.0, now, ramp);
      }
    }
  }

  // Get current reduction in dB from limiter (negative number when compressing)
  public getLimiterReduction(): number {
    if (!this.limiter) return 0;
    return this.limiter.reduction; // returns float in dB
  }

  public getAudioContext(): AudioContext | null {
    return this.ctx;
  }

  public async resume(): Promise<void> {
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }
}

export const dspEngine = new DSPEngine();
