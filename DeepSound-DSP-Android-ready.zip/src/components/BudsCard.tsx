import React, { useState } from 'react';
import { BudsInfo } from '../types/audio';
import {
  Bluetooth,
  BatteryCharging,
  Zap,
  Radio,
  Sliders,
  CheckCircle2,
  VolumeX,
  Volume2,
} from 'lucide-react';

interface BudsCardProps {
  budsInfo: BudsInfo;
  onUpdateBuds: (newInfo: Partial<BudsInfo>) => void;
}

export const BudsCard: React.FC<BudsCardProps> = ({
  budsInfo,
  onUpdateBuds,
}) => {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div className="w-full bg-gradient-to-r from-[#0d1424] via-[#0f172a] to-[#0c1220] rounded-2xl border border-sky-900/40 p-3.5 shadow-xl relative overflow-hidden">
      {/* Background neon ambient highlight */}
      <div className="absolute -right-12 -top-12 w-48 h-48 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        {/* Left: Device Name & Bluetooth Status */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-sky-500/20 to-purple-600/30 border border-sky-400/40 flex items-center justify-center text-sky-400 shadow-[0_0_15px_rgba(56,189,248,0.2)]">
              <Bluetooth className="w-5 h-5 animate-pulse" />
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-900" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white tracking-tight">
                {budsInfo.model}
              </h3>
              <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                <span>Подключено</span>
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-400 font-mono">
              <span className="bg-slate-800/80 px-1.5 py-0.5 rounded text-sky-300 font-bold border border-slate-700/60">
                {budsInfo.codec} 24-bit / 96kHz
              </span>
              <span>L: {budsInfo.batteryLeft}%</span>
              <span>R: {budsInfo.batteryRight}%</span>
              <span>Кейс: {budsInfo.batteryCase}%</span>
            </div>
          </div>
        </div>

        {/* Right: Quick toggles */}
        <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
          {/* 360 Audio button */}
          <button
            onClick={() => onUpdateBuds({ spatial360: !budsInfo.spatial360 })}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
              budsInfo.spatial360
                ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 shadow-[0_0_12px_rgba(168,85,247,0.25)]'
                : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>360° Audio</span>
          </button>

          {/* Details toggle */}
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800/60 text-slate-300 hover:text-white border border-slate-700/60 transition"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>{showDetails ? 'Скрыть' : 'Настройки Buds'}</span>
          </button>
        </div>
      </div>

      {/* Expanded Buds4 Pro settings panel */}
      {showDetails && (
        <div className="mt-3.5 pt-3.5 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Noise Control Mode */}
          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 font-medium block mb-1.5">
              Управление шумом:
            </span>
            <div className="grid grid-cols-3 gap-1">
              {(['anc', 'ambient', 'off'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => onUpdateBuds({ ancMode: mode })}
                  className={`py-1 text-[11px] font-semibold rounded-lg border transition ${
                    budsInfo.ancMode === mode
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/40 hover:text-slate-200'
                  }`}
                >
                  {mode === 'anc' ? 'ANC' : mode === 'ambient' ? 'Фон' : 'Выкл'}
                </button>
              ))}
            </div>
          </div>

          {/* Codec Selection */}
          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 font-medium block mb-1.5">
              Bluetooth Кодек:
            </span>
            <div className="grid grid-cols-3 gap-1">
              {(['SSC', 'LDAC', 'AAC'] as const).map((cdc) => (
                <button
                  key={cdc}
                  onClick={() => onUpdateBuds({ codec: cdc })}
                  className={`py-1 text-[11px] font-semibold rounded-lg border transition ${
                    budsInfo.codec === cdc
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40 font-mono'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/40 hover:text-slate-200 font-mono'
                  }`}
                >
                  {cdc}
                </button>
              ))}
            </div>
          </div>

          {/* Ultra-low Latency Gaming Mode */}
          <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>Игровой режим</span>
              </div>
              <span className="text-[10px] text-slate-400">Минимальная задержка</span>
            </div>
            <button
              onClick={() => onUpdateBuds({ gamingMode: !budsInfo.gamingMode })}
              className={`w-11 h-6 rounded-full transition p-0.5 border ${
                budsInfo.gamingMode
                  ? 'bg-amber-500 border-amber-400 justify-end'
                  : 'bg-slate-800 border-slate-700 justify-start'
              } flex items-center`}
            >
              <div className="w-5 h-5 rounded-full bg-white shadow-md" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
