import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Smartphone, Download, X, HelpCircle } from 'lucide-react';
import { ApkModal } from './ApkModal';

export const InstallGuideBanner: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  if (isInstalled || dismissed) return (
    <>
      <ApkModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
    </>
  );

  return (
    <>
      <div className="w-full bg-gradient-to-r from-sky-950/40 via-indigo-950/30 to-purple-950/40 border border-sky-500/30 rounded-2xl p-3 sm:p-4 mb-4 backdrop-blur-md relative shadow-lg">
        <button
          onClick={() => setDismissed(true)}
          className="absolute top-2.5 right-2.5 p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-6">
          <div className="flex items-start sm:items-center gap-3">
            <div className="p-2.5 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-400/30 shrink-0">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <span>DeepSound для Android & Samsung Galaxy</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded font-mono">
                  APK / WebAPK
                </span>
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Установите на телефон в один клик: компилируется в нативный Android пакет со значком в меню и фоновым DSP.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 flex-wrap">
            {isInstallable ? (
              <button
                onClick={install}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold text-xs shadow-[0_0_15px_rgba(56,189,248,0.3)] transition"
              >
                <Download className="w-4 h-4" />
                <span>Установить APK на телефон</span>
              </button>
            ) : isIOS ? (
              <span className="text-[11px] text-slate-400 bg-slate-850 px-3 py-1.5 rounded-xl border border-slate-700">
                В Safari: <strong>«Поделиться»</strong> → <strong>«На экран Домой»</strong>
              </span>
            ) : (
              <span className="text-[11px] text-slate-400 bg-slate-850 px-3 py-1.5 rounded-xl border border-slate-700">
                В Chrome: меню <strong>(⋮)</strong> → <strong>«Установить приложение»</strong>
              </span>
            )}

            <button
              onClick={() => setIsApkModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-sky-300 border border-slate-700/80 text-xs font-medium transition"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Про APK</span>
            </button>
          </div>
        </div>
      </div>

      <ApkModal isOpen={isApkModalOpen} onClose={() => setIsApkModalOpen(false)} />
    </>
  );
};
