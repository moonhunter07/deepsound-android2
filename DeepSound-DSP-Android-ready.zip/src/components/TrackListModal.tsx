import React, { useRef } from 'react';
import { AudioTrack } from '../types/audio';
import {
  X,
  Upload,
  Music,
  Play,
  Volume2,
  Trash2,
  FileAudio,
  Sparkles,
} from 'lucide-react';

interface TrackListModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: AudioTrack[];
  currentTrackId: string | null;
  isPlaying: boolean;
  onSelectTrack: (track: AudioTrack) => void;
  onAddFiles: (files: FileList) => void;
  onRemoveTrack: (trackId: string) => void;
}

export const TrackListModal: React.FC<TrackListModalProps> = ({
  isOpen,
  onClose,
  tracks,
  currentTrackId,
  isPlaying,
  onSelectTrack,
  onAddFiles,
  onRemoveTrack,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onAddFiles(e.target.files);
    }
  };

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[85vh] bg-[#0c1220] border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/20">
              <Music className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                Аудиотека & Треки
              </h2>
              <p className="text-xs text-slate-400">
                Открывайте музыку с телефона или слушайте Hi-Fi демо
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Upload Button Banner */}
        <div className="p-4 bg-slate-900/60 border-b border-slate-800/80">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            multiple
            accept="audio/*,.mp3,.flac,.wav,.m4a,.aac,.ogg"
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center justify-center gap-2.5 py-3 px-4 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-[0_0_20px_rgba(56,189,248,0.25)] transition border border-sky-400/40"
          >
            <Upload className="w-4 h-4" />
            <span>Выбрать треки с устройства (MP3, FLAC, WAV, AAC)</span>
          </button>
        </div>

        {/* Track List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {tracks.map((track) => {
            const isSelected = track.id === currentTrackId;

            return (
              <div
                key={track.id}
                onClick={() => onSelectTrack(track)}
                className={`group flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-sky-950/30 border-sky-500/50 shadow-md ring-1 ring-sky-500/30'
                    : 'bg-slate-900/40 border-slate-800/60 hover:bg-slate-850/60 hover:border-slate-700/60'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                      isSelected
                        ? 'bg-sky-500/20 text-sky-400 border-sky-500/40'
                        : 'bg-slate-800/80 text-slate-400 border-slate-700/60 group-hover:text-slate-200'
                    }`}
                  >
                    {isSelected && isPlaying ? (
                      <Volume2 className="w-5 h-5 animate-pulse text-sky-400" />
                    ) : (
                      <Play className="w-4 h-4 ml-0.5" />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm font-semibold truncate ${isSelected ? 'text-sky-300' : 'text-slate-200'}`}>
                        {track.title}
                      </span>
                      {track.type === 'demo' ? (
                        <span className="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-300 border border-purple-500/20 font-mono">
                          Hi-Fi Demo
                        </span>
                      ) : (
                        <span className="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 font-mono">
                          Файл
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span className="truncate">{track.artist}</span>
                      {track.genre && (
                        <>
                          <span>•</span>
                          <span className="truncate text-slate-400 font-mono">{track.genre}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-2">
                  <span className="text-xs font-mono text-slate-400">
                    {formatDuration(track.duration)}
                  </span>

                  {track.type === 'local' && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveTrack(track.id);
                      }}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                      title="Удалить из списка"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-center text-xs text-slate-400">
          Весь воспроизводимый звук проходит через DSP движок перед передачей по Bluetooth на Galaxy Buds4 Pro.
        </div>
      </div>
    </div>
  );
};
