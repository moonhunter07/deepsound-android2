import React, { useEffect, useRef, useState } from 'react';
import { dspEngine } from '../services/dspEngine';
import { Activity, Radio, Waves, ShieldCheck } from 'lucide-react';

interface VisualizerProps {
  isPlaying: boolean;
  bypass: boolean;
  limiterEnabled: boolean;
  subBassLevel: number;
}

type VizMode = 'spectrum' | 'waveform' | 'spatial';

export const Visualizer: React.FC<VisualizerProps> = ({
  isPlaying,
  bypass,
  limiterEnabled,
  subBassLevel,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [vizMode, setVizMode] = useState<VizMode>('spectrum');
  const [limiterReductionDb, setLimiterReductionDb] = useState<number>(0);
  const animFrameIdRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let dpr = window.devicePixelRatio || 1;

    const resize = () => {
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };
    resize();
    window.addEventListener('resize', resize);

    const freqData = new Uint8Array(512);
    const timeData = new Uint8Array(512);
    const timeDataL = new Uint8Array(256);
    const timeDataR = new Uint8Array(256);

    let peakValues = new Float32Array(64).fill(0);
    let lastLimiterCheck = 0;

    const render = (timestamp: number) => {
      animFrameIdRef.current = requestAnimationFrame(render);

      const width = canvas.clientWidth;
      const height = canvas.clientHeight;
      ctx.clearRect(0, 0, width, height);

      // Periodically sample limiter reduction
      if (timestamp - lastLimiterCheck > 60) {
        lastLimiterCheck = timestamp;
        const red = dspEngine.getLimiterReduction();
        setLimiterReductionDb(red);
      }

      if (!isPlaying || !dspEngine.analyser) {
        // Idle animation / quiet glowing flatline
        ctx.strokeStyle = bypass ? 'rgba(148, 163, 184, 0.2)' : 'rgba(56, 189, 248, 0.25)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        const midY = height / 2;
        for (let x = 0; x < width; x += 10) {
          const y = midY + Math.sin((x * 0.03) + (timestamp * 0.002)) * 3;
          if (x === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
        return;
      }

      if (vizMode === 'spectrum') {
        dspEngine.analyser.getByteFrequencyData(freqData);

        const barCount = 48;
        const spacing = 3;
        const totalBarWidth = (width - spacing * (barCount - 1)) / barCount;
        const barWidth = Math.max(2, totalBarWidth);

        // Sub bass ambient glow behind the bars
        if (!bypass && subBassLevel > 40) {
          let lowEnergy = 0;
          for (let i = 0; i < 6; i++) lowEnergy += freqData[i];
          lowEnergy /= 6;
          if (lowEnergy > 50) {
            const glowOpacity = Math.min(0.35, (lowEnergy / 255) * (subBassLevel / 100));
            const gradient = ctx.createRadialGradient(
              width / 4, height, 10,
              width / 4, height, width * 0.6
            );
            gradient.addColorStop(0, `rgba(56, 189, 248, ${glowOpacity})`);
            gradient.addColorStop(0.5, `rgba(168, 85, 247, ${glowOpacity * 0.4})`);
            gradient.addColorStop(1, 'transparent');
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);
          }
        }

        // Draw frequency bars
        for (let i = 0; i < barCount; i++) {
          // Logarithmic bin mapping for human hearing
          const freqIndex = Math.floor(Math.pow(i / barCount, 1.8) * 180);
          const val = freqData[freqIndex] || 0;
          const barHeight = Math.max(3, (val / 255) * (height - 18));
          const x = i * (barWidth + spacing);
          const y = height - barHeight;

          // Decay peaks
          if (barHeight > peakValues[i]) {
            peakValues[i] = barHeight;
          } else {
            peakValues[i] = Math.max(0, peakValues[i] - 1.2);
          }

          // Color gradient across spectrum
          const grad = ctx.createLinearGradient(0, height, 0, y);
          if (bypass) {
            grad.addColorStop(0, '#475569');
            grad.addColorStop(1, '#94a3b8');
          } else {
            if (i < 8) {
              // Sub-bass (30Hz - 60Hz)
              grad.addColorStop(0, '#0284c7');
              grad.addColorStop(0.6, '#38bdf8');
              grad.addColorStop(1, '#67e8f9');
            } else if (i < 20) {
              // Bass & Low-Mids
              grad.addColorStop(0, '#4f46e5');
              grad.addColorStop(0.6, '#818cf8');
              grad.addColorStop(1, '#a78bfa');
            } else if (i < 34) {
              // Clarity / Vocals
              grad.addColorStop(0, '#7c3aed');
              grad.addColorStop(0.6, '#c084fc');
              grad.addColorStop(1, '#f472b6');
            } else {
              // Treble / Air
              grad.addColorStop(0, '#c026d3');
              grad.addColorStop(0.5, '#f43f5e');
              grad.addColorStop(1, '#fde047');
            }
          }

          ctx.fillStyle = grad;
          // Rounded top bars
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, [3, 3, 0, 0]);
          ctx.fill();

          // Peak cap
          if (peakValues[i] > 4) {
            const peakY = height - peakValues[i] - 2;
            ctx.fillStyle = bypass ? '#cbd5e1' : '#f8fafc';
            ctx.fillRect(x, Math.max(0, peakY), barWidth, 2);
          }
        }
      } else if (vizMode === 'waveform') {
        dspEngine.analyser.getByteTimeDomainData(timeData);
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = bypass ? '#94a3b8' : '#38bdf8';
        ctx.beginPath();

        const sliceWidth = width / 512;
        let x = 0;
        for (let i = 0; i < 512; i++) {
          const v = timeData[i] / 128.0;
          const y = (v * height) / 2;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
          x += sliceWidth;
        }
        ctx.stroke();

        // Soft glow under wave
        ctx.shadowColor = bypass ? 'transparent' : '#0ea5e9';
        ctx.shadowBlur = 8;
        ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (vizMode === 'spatial') {
        // Lissajous / Stereo Vector Scope
        if (dspEngine.stereoAnalyserL && dspEngine.stereoAnalyserR) {
          dspEngine.stereoAnalyserL.getByteTimeDomainData(timeDataL);
          dspEngine.stereoAnalyserR.getByteTimeDomainData(timeDataR);

          const centerX = width / 2;
          const centerY = height / 2;
          const scale = Math.min(centerX, centerY) * 0.85;

          // Draw spatial background grid circles
          ctx.strokeStyle = 'rgba(255,255,255,0.06)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(centerX, centerY, scale * 0.4, 0, 2 * Math.PI);
          ctx.arc(centerX, centerY, scale * 0.8, 0, 2 * Math.PI);
          ctx.stroke();

          // Draw stereo correlation Lissajous curve
          ctx.strokeStyle = bypass ? '#94a3b8' : '#a855f7';
          ctx.lineWidth = 1.8;
          ctx.beginPath();

          for (let i = 0; i < 256; i += 2) {
            const l = (timeDataL[i] - 128) / 128.0;
            const r = (timeDataR[i] - 128) / 128.0;

            // Rotate 45 degrees: Mid = X, Side = Y
            const mid = (l + r) * 0.7071;
            const side = (l - r) * 0.7071;

            const px = centerX + side * scale;
            const py = centerY - mid * scale;

            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.stroke();

          // Axis markers (L - R - C)
          ctx.fillStyle = 'rgba(255,255,255,0.3)';
          ctx.font = '10px monospace';
          ctx.fillText('L', centerX - scale * 0.9, centerY + 4);
          ctx.fillText('R', centerX + scale * 0.8, centerY + 4);
          ctx.fillText('C', centerX - 4, centerY - scale * 0.85);
        }
      }
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameIdRef.current) cancelAnimationFrame(animFrameIdRef.current);
      window.removeEventListener('resize', resize);
    };
  }, [isPlaying, bypass, vizMode, limiterEnabled, subBassLevel]);

  // Calculate limiter bar percentage (0 to -12dB range)
  const reductionAmount = Math.abs(limiterReductionDb);
  const reductionPercent = Math.min(100, (reductionAmount / 12) * 100);

  return (
    <div className="relative w-full rounded-2xl bg-gradient-to-b from-[#0c1220]/90 to-[#070b14]/95 p-3.5 border border-slate-800/80 shadow-xl backdrop-blur-md overflow-hidden">
      {/* Top bar with mode selector and status */}
      <div className="flex items-center justify-between mb-2 px-1">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-900/90 border border-slate-800/90 rounded-lg p-0.5">
            <button
              onClick={() => setVizMode('spectrum')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition ${
                vizMode === 'spectrum'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3 h-3" />
              <span>Спектр</span>
            </button>
            <button
              onClick={() => setVizMode('waveform')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition ${
                vizMode === 'waveform'
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Waves className="w-3 h-3" />
              <span>Волна</span>
            </button>
            <button
              onClick={() => setVizMode('spatial')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium transition ${
                vizMode === 'spatial'
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Radio className="w-3 h-3" />
              <span>3D Сцена</span>
            </button>
          </div>
        </div>

        {/* Real-time Limiter / Anti-clipping status indicator */}
        <div className="flex items-center gap-2">
          {limiterEnabled && (
            <div
              className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-mono border transition ${
                reductionAmount > 0.5
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
              }`}
              title="Ограничитель активен: подавляет хрип и клиппинг при усилении баса и громкости"
            >
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              <span>{reductionAmount > 0.5 ? `Лимитер: -${reductionAmount.toFixed(1)}dB` : 'Анти-хрип OK'}</span>
            </div>
          )}

          {bypass ? (
            <span className="px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-semibold bg-slate-800 text-slate-400 border border-slate-700">
              Dry (Байпас)
            </span>
          ) : (
            <span className="px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-semibold bg-gradient-to-r from-sky-500/20 to-purple-500/20 text-sky-300 border border-sky-500/30 shadow-[0_0_10px_rgba(56,189,248,0.2)]">
              DSP 32-bit Hi-Fi
            </span>
          )}
        </div>
      </div>

      {/* Canvas */}
      <div className="relative w-full h-32 md:h-36 rounded-xl bg-[#05080f]/80 overflow-hidden border border-slate-800/40">
        <canvas ref={canvasRef} className="w-full h-full block" />

        {/* Frequency band tags for spectrum */}
        {vizMode === 'spectrum' && (
          <div className="absolute bottom-1 left-0 right-0 flex justify-between px-3 text-[9px] font-mono text-slate-500/80 pointer-events-none">
            <span>30Hz (Sub)</span>
            <span>120Hz (Bass)</span>
            <span>1kHz</span>
            <span>3.5kHz (Clarity)</span>
            <span>10kHz (Treble)</span>
          </div>
        )}

        {/* Gain Reduction Meter Overlay on high transients */}
        {reductionAmount > 0.5 && (
          <div className="absolute top-2 right-2 bg-slate-900/90 border border-amber-500/40 rounded px-1.5 py-0.5 flex items-center gap-1 text-[10px] text-amber-300 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
            <span>Сжатие пиков: -{reductionAmount.toFixed(1)} dB</span>
          </div>
        )}
      </div>

      {/* Dynamic Limiter visual bar */}
      {limiterEnabled && reductionPercent > 0 && (
        <div className="mt-1.5 flex items-center gap-2 px-1">
          <span className="text-[10px] text-slate-400 font-mono">GR (Защита от хрипа):</span>
          <div className="flex-1 h-1.5 bg-slate-800/80 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-400 via-amber-400 to-rose-400 transition-all duration-75"
              style={{ width: `${reductionPercent}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
