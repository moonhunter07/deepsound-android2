import React from 'react';
import { AudioTrack } from '../types/audio';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Repeat,
  Repeat1,
  Shuffle,
  ListMusic,
  FolderPlus,
} from 'lucide-react';

interface PlayerControlsProps {
  currentTrack: AudioTrack | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  loopMode: 'off' | 'all' | 'one';
  shuffle: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrevious: () => void;
  onSeek: (time: number) => void;
  onVolumeChange: (vol: number) => void;
  onToggleMute: () => void;
  onToggleLoop: () => void;
  onToggleShuffle: () => void;
  onOpenLibrary: () => void;
}

export const PlayerControls: React.FC<PlayerControlsProps> = ({
  currentTrack,
  isPlaying,
  currentTime,
  duration,
  volume,
  isMuted,
  loopMode,
  shuffle,
  onPlayPause,
  onNext,
  onPrevious,
  onSeek,
  onVolumeChange,
  onToggleMute,
  onToggleLoop,
  onToggleShuffle,
  onOpenLibrary,
}) => {
  const formatTime = (sec: number) => {
    if (isNaN(sec) || sec < 0) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="w-full bg-[#0a0f1d]/95 border border-slate-800/80 rounded-2xl p-4 shadow-2xl backdrop-blur-xl">
      {/* Seek Progress Bar */}
      <div className="mb-3">
        <div className="relative group flex items-center">
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none transition group-hover:h-2.5"
            style={{
              background: `linear-gradient(to right, rgb(56, 189, 248) 0%, rgb(168, 85, 247) ${progressPercent}%, rgb(30, 41, 59) ${progressPercent}%, rgb(30, 41, 59) 100%)`,
            }}
          />
        </div>
        <div className="flex justify-between text-[11px] font-mono text-slate-400 mt-1">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Track Info */}
        <div className="flex items-center gap-3 w-full sm:w-1/3 min-w-0">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-sky-500/20 via-purple-500/20 to-slate-800 border border-slate-700/60 flex items-center justify-center shrink-0 shadow-md">
            <span className="text-xl">🎵</span>
          </div>

          <div className="min-w-0">
            <h4 className="text-sm font-bold text-white truncate">
              {currentTrack ? currentTrack.title : 'Выберите трек для воспроизведения'}
            </h4>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              <span className="truncate">{currentTrack?.artist || 'DeepSound Engine'}</span>
              {currentTrack?.format && (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-sky-300 font-mono">
                  {currentTrack.format}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Central Playback Controls */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={onToggleShuffle}
            className={`p-2 rounded-xl transition ${
              shuffle ? 'text-sky-400 bg-sky-500/10' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Перемешать"
          >
            <Shuffle className="w-4 h-4" />
          </button>

          <button
            onClick={onPrevious}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition"
            title="Предыдущий трек"
          >
            <SkipBack className="w-5 h-5" />
          </button>

          <button
            onClick={onPlayPause}
            className="w-12 h-12 rounded-full bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 hover:scale-105 active:scale-95 text-white flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.4)] transition-all"
            title={isPlaying ? 'Пауза' : 'Воспроизвести'}
          >
            {isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current ml-0.5" />
            )}
          </button>

          <button
            onClick={onNext}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/80 transition"
            title="Следующий трек"
          >
            <SkipForward className="w-5 h-5" />
          </button>

          <button
            onClick={onToggleLoop}
            className={`p-2 rounded-xl transition ${
              loopMode !== 'off' ? 'text-purple-400 bg-purple-500/10' : 'text-slate-400 hover:text-slate-200'
            }`}
            title={loopMode === 'one' ? 'Повтор 1 трека' : loopMode === 'all' ? 'Повтор списка' : 'Повтор выкл'}
          >
            {loopMode === 'one' ? (
              <Repeat1 className="w-4 h-4" />
            ) : (
              <Repeat className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Volume & Library Buttons */}
        <div className="flex items-center justify-end gap-3 w-full sm:w-1/3">
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleMute}
              className="text-slate-400 hover:text-white transition"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={isMuted ? 0 : volume}
              onChange={(e) => onVolumeChange(Number(e.target.value))}
              className="w-20 sm:w-24 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none"
            />
          </div>

          <button
            onClick={onOpenLibrary}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-xs font-semibold text-slate-200 border border-slate-700/60 transition shadow-sm"
          >
            <ListMusic className="w-3.5 h-3.5 text-sky-400" />
            <span>Треки</span>
          </button>
        </div>
      </div>
    </div>
  );
};
