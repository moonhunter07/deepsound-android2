import React, { useState } from 'react';
import {
  X,
  Smartphone,
  CheckCircle2,
  ExternalLink,
  Layers,
  Copy,
  Check,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface ApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkModal: React.FC<ApkModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';

  if (!isOpen) return null;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-[#0c1220] border border-sky-500/30 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-sky-500/20 text-emerald-400 border border-emerald-500/30 shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Установка в формате APK на Android</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                  WebAPK / APK
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Как получить официальный APK-пакет или установить без Google Play
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-slate-300 text-xs sm:text-sm">
          {/* Method 1: Direct WebAPK on Android */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/40 shadow-lg">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-1.5">
              <Zap className="w-4 h-4 text-emerald-400" />
              <span>Способ 1. Установка официального APK прямо сейчас (на POCO / Android)</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed mb-3">
              Вам <strong>не нужно</strong> искать сторонние сайты для конвертации. Android (включая оболочку MIUI / HyperOS на POCO F4 GT) сам создает полноценный <strong>.apk</strong> пакет при установке через Chrome:
            </p>

            <div className="bg-slate-950/70 rounded-xl p-3 border border-slate-800/80 space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Нажмите вверху кнопку <strong>«Установить APK на телефон»</strong> (или в Chrome: <strong>три точки ⋮ → Установить приложение</strong>).</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Google Play Services на вашем телефоне скомпилирует системный пакет <strong>DeepSound.apk</strong>.</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Проверьте: зайдите в <strong>«Настройки» → «Приложения» → «Все приложения»</strong> — там будет полноценный DeepSound с выделенной памятью, разрешениями и иконкой на рабочем столе.</span>
              </div>
            </div>
          </div>

          {/* Method 2: Android Studio / Capacitor APK Build */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="flex items-center gap-2 text-sky-400 font-bold text-sm mb-1.5">
              <Layers className="w-4 h-4 text-sky-400" />
              <span>Способ 2. Как собрать автономный .apk файл через Capacitor / Android Studio</span>
            </div>
            <p className="text-slate-400 text-xs mb-3">
              Если вам требуется отдельный бинарный файл <strong>.apk</strong> (debug/release) для распространения:
            </p>

            <ol className="list-decimal list-inside space-y-2 text-xs text-slate-300 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
              <li>
                Скачайте исходный код проекта (в верхнем меню AI Studio: кнопка <strong>«Export / Download Code»</strong>).
              </li>
              <li>
                В папке проекта выполните сборку в нативный Android проект:
                <div className="mt-1.5 bg-black/70 p-2 rounded-lg font-mono text-[11px] text-emerald-400 space-y-1">
                  <div>npm install @capacitor/core @capacitor/android</div>
                  <div>npx cap init DeepSound com.deepsound.dsp</div>
                  <div>npm run build && npx cap add android</div>
                  <div>npx cap open android</div>
                </div>
              </li>
              <li>
                В открывшемся <strong>Android Studio</strong> нажмите <strong>Build → Build Bundle(s) / APK(s) → Build APK(s)</strong>.
              </li>
              <li>
                Готовый файл <strong>app-debug.apk</strong> появится в папке <code className="text-sky-300">android/app/build/outputs/apk/</code>.
              </li>
            </ol>
          </div>

          {/* Android settings notice */}
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200/90 text-xs">
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <span>
              DeepSound полностью совместим с Android WebView и Android 10–15, поддерживает частоту дискретизации 96 кГц и кодек Samsung Seamless Codec (SSC).
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition shadow-md"
          >
            Понятно
          </button>
        </div>
      </div>
    </div>
  );
};
