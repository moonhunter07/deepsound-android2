import React from 'react';
import { Volume2, Power, Download, Sparkles, Smartphone, Check } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  bypass: boolean;
  onToggleBypass: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  bypass,
  onToggleBypass,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();

  return (
    <header className="w-full bg-[#080d19]/90 border-b border-slate-800/80 sticky top-0 z-40 backdrop-blur-xl px-4 py-3">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
        {/* Logo and Device title */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-purple-600 p-0.5 shadow-[0_0_20px_rgba(56,189,248,0.35)] flex items-center justify-center">
              <div className="w-full h-full bg-[#080d1a] rounded-[10px] flex items-center justify-center">
                <Volume2 className="w-5 h-5 text-sky-400" />
              </div>
            </div>
            {!bypass && (
              <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-sky-500" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black tracking-tight bg-gradient-to-r from-white via-slate-100 to-sky-300 bg-clip-text text-transparent">
                DeepSound DSP
              </h1>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/10 text-sky-400 border border-sky-500/20">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Аудиопроцессор и плеер для Samsung Galaxy Buds4 Pro
            </p>
          </div>
        </div>

        {/* Right action buttons: Bypass A/B switch & PWA Install */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* DSP Bypass Switch (A/B testing) */}
          <button
            onClick={onToggleBypass}
            className={`flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-bold transition-all shadow-md border ${
              bypass
                ? 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                : 'bg-gradient-to-r from-sky-500 to-indigo-600 text-white border-sky-400/50 shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:brightness-110'
            }`}
            title="Сравните исходный звук с обработанным звуком DeepSound DSP"
          >
            <Power className={`w-3.5 h-3.5 ${bypass ? 'text-slate-400' : 'text-white'}`} />
            <span>{bypass ? 'DSP: ВЫКЛ (Сухой)' : 'DSP: ВКЛ (Hi-Fi)'}</span>
          </button>

          {/* Android PWA Install Button */}
          {isInstallable && (
            <button
              onClick={install}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 transition shadow-sm"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">Установить</span>
              <span className="xs:hidden">APK</span>
            </button>
          )}

          {isInstalled && (
            <div className="hidden md:flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
              <Check className="w-3 h-3 text-emerald-400" />
              <span>PWA активна</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
