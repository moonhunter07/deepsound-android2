import React from 'react';
import { DSPSettings } from '../types/audio';
import {
  Volume2,
  Sparkles,
  Music,
  Globe2,
  Flame,
  Shield,
  ShieldAlert,
  Headphones,
  RotateCcw,
  Radio,
  Compass,
} from 'lucide-react';

interface DSPControlsProps {
  settings: DSPSettings;
  onChange: (newSettings: DSPSettings) => void;
  onReset: () => void;
  disabled?: boolean;
}

export const DSPControls: React.FC<DSPControlsProps> = ({
  settings,
  onChange,
  onReset,
  disabled = false,
}) => {
  const updateSetting = <K extends keyof DSPSettings>(key: K, value: DSPSettings[K]) => {
    onChange({
      ...settings,
      [key]: value,
    });
  };

  const sliders = [
    {
      key: 'subBass' as const,
      label: 'Depth / Sub Bass',
      labelRu: 'Глубина / Суб-Бас',
      desc: '30-50 Гц: фундаментальная глубина и бархатный напор для 11мм вуфера',
      icon: Headphones,
      unit: '%',
      color: 'from-sky-500 to-cyan-400',
      glowColor: 'rgba(56, 189, 248, 0.4)',
      accentClass: 'text-sky-400',
      min: 0,
      max: 100,
    },
    {
      key: 'bass' as const,
      label: 'Bass',
      labelRu: 'Бас (Панч)',
      desc: '100-160 Гц: плотный удар бочки и ритмический драйв',
      icon: Volume2,
      unit: '%',
      color: 'from-blue-600 to-indigo-500',
      glowColor: 'rgba(99, 102, 241, 0.4)',
      accentClass: 'text-indigo-400',
      min: 0,
      max: 100,
    },
    {
      key: 'clarity' as const,
      label: 'Clarity',
      labelRu: 'Четкость / Вокал',
      desc: '3.2-4.5 кГц: разборчивость слов, прозрачность голоса и атака струн',
      icon: Sparkles,
      unit: '%',
      color: 'from-purple-500 to-pink-500',
      glowColor: 'rgba(168, 85, 247, 0.4)',
      accentClass: 'text-purple-400',
      min: 0,
      max: 100,
    },
    {
      key: 'treble' as const,
      label: 'Treble',
      labelRu: 'Высокие / Воздух',
      desc: '9-16 кГц: кристальные обертоны и сцена планарного твитера',
      icon: Music,
      unit: '%',
      color: 'from-fuchsia-500 to-rose-400',
      glowColor: 'rgba(244, 63, 94, 0.4)',
      accentClass: 'text-rose-400',
      min: 0,
      max: 100,
    },
    {
      key: 'stereoWidth' as const,
      label: 'Stereo Width',
      labelRu: '3D Стерео Сцена',
      desc: 'Mid/Side фазовое расширение: панорама как на живом концерте',
      icon: Globe2,
      unit: '%',
      color: 'from-teal-400 to-emerald-400',
      glowColor: 'rgba(20, 184, 166, 0.4)',
      accentClass: 'text-teal-400',
      min: 0,
      max: 100,
    },
    {
      key: 'loudness' as const,
      label: 'Loudness',
      labelRu: 'Громкость / Насыщение',
      desc: 'Теплое ламповое насыщение: увеличивает плотность без перегруза',
      icon: Flame,
      unit: '%',
      color: 'from-amber-500 to-orange-500',
      glowColor: 'rgba(245, 158, 11, 0.4)',
      accentClass: 'text-amber-400',
      min: 0,
      max: 100,
    },
  ];

  return (
    <div className="w-full bg-[#0b101c]/90 rounded-2xl border border-slate-800/80 p-4 md:p-5 shadow-2xl backdrop-blur-md">
      {/* Header of DSP controls */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
              <span>Параметры звука DeepSound DSP</span>
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 font-mono">
              Galaxy Buds4 Pro
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Точная настройка звучания под ваши наушники в реальном времени
          </p>
        </div>

        <button
          onClick={onReset}
          disabled={disabled}
          title="Сбросить в нейтральное положение"
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-slate-700/50 transition disabled:opacity-50"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Сброс</span>
        </button>
      </div>

      {/* Sliders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {sliders.map((slider) => {
          const Icon = slider.icon;
          const val = settings[slider.key];
          const isNeutralWidth = slider.key === 'stereoWidth' && val === 50;

          return (
            <div
              key={slider.key}
              className={`p-3 rounded-xl bg-slate-900/60 border border-slate-800/60 hover:border-slate-700/80 transition-all ${
                disabled ? 'opacity-50 pointer-events-none' : ''
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-lg bg-slate-800/80 ${slider.accentClass}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <span>{slider.labelRu}</span>
                      <span className="text-[10px] text-slate-400 font-normal">({slider.label})</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <span className="text-xs font-mono font-bold text-white bg-slate-800/90 px-2 py-0.5 rounded border border-slate-700/60">
                    {val}{slider.unit}
                  </span>
                </div>
              </div>

              <p className="text-[11px] text-slate-400/90 mb-2 leading-tight">
                {slider.desc}
              </p>

              {/* Slider track */}
              <div className="relative flex items-center">
                <input
                  type="range"
                  min={slider.min}
                  max={slider.max}
                  value={val}
                  onChange={(e) => updateSetting(slider.key, Number(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400 focus:outline-none"
                  style={{
                    background: `linear-gradient(to right, rgb(56, 189, 248) 0%, rgb(168, 85, 247) ${val}%, rgb(30, 41, 59) ${val}%, rgb(30, 41, 59) 100%)`,
                  }}
                />
              </div>

              {/* Footer marks */}
              <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mt-1">
                <span>0%</span>
                {slider.key === 'stereoWidth' && (
                  <span className={isNeutralWidth ? 'text-teal-400 font-semibold' : ''}>
                    50% (Стерео 1x)
                  </span>
                )}
                <span>100% (Max)</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Spatial 360 HRTF Virtual Surround Card */}
      <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-r from-purple-950/30 via-slate-900/70 to-slate-900/60 border border-purple-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg relative overflow-hidden">
        {settings.spatial360 && (
          <div className="absolute -right-8 -top-8 w-32 h-32 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
        )}
        <div className="flex items-start sm:items-center gap-3">
          <div className={`p-2.5 rounded-xl transition ${
            settings.spatial360
              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.3)]'
              : 'bg-slate-800 text-slate-400 border border-slate-700/60'
          }`}>
            <Radio className={`w-5 h-5 ${settings.spatial360 ? 'animate-pulse' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-100 flex items-center gap-1.5">
                <span>Spatial 360 (HRTF Виртуальный объем)</span>
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                settings.spatial360
                  ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                  : 'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>
                {settings.spatial360 ? 'ВКЛ (360° HRTF)' : 'ВЫКЛ'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
              Бинауральное пространственное панорамирование Web Audio HRTF для Galaxy Buds4 Pro: моделирует виртуальную сцену с локализацией звуков вокруг головы.
            </p>
          </div>
        </div>

        <button
          onClick={() => updateSetting('spatial360', !settings.spatial360)}
          disabled={disabled}
          className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold transition border flex items-center justify-center gap-1.5 ${
            settings.spatial360
              ? 'bg-purple-500/25 text-purple-200 border-purple-500/50 hover:bg-purple-500/35 shadow-[0_0_12px_rgba(168,85,247,0.25)]'
              : 'bg-slate-800/80 text-slate-300 border-slate-700/80 hover:bg-slate-750 hover:text-white'
          }`}
        >
          <Compass className={`w-3.5 h-3.5 ${settings.spatial360 ? 'text-purple-300 animate-spin-slow' : 'text-slate-400'}`} />
          <span>{settings.spatial360 ? '360° Surround Активен' : 'Включить 360° Audio'}</span>
        </button>
      </div>

      {/* Limiter / Anti-clipping Card */}
      <div className="mt-4 p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/20 via-slate-900/60 to-slate-900/60 border border-emerald-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-start sm:items-center gap-3">
          <div className={`p-2 rounded-xl ${settings.limiterEnabled ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
            {settings.limiterEnabled ? (
              <Shield className="w-5 h-5" />
            ) : (
              <ShieldAlert className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-slate-100">
                Ограничитель перегрузки (Анти-хрип)
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                settings.limiterEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
              }`}>
                {settings.limiterEnabled ? 'ВКЛЮЧЕН (Рекомендуется)' : 'ВЫКЛЮЧЕН'}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Brickwall Limiter 20:1 + мягкое сглаживание: предотвращает треск и захлебывание мембраны наушников при высоком басе и громкости.
            </p>
          </div>
        </div>

        <button
          onClick={() => updateSetting('limiterEnabled', !settings.limiterEnabled)}
          disabled={disabled}
          className={`shrink-0 px-4 py-2 rounded-xl text-xs font-semibold transition border ${
            settings.limiterEnabled
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
              : 'bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30'
          }`}
        >
          {settings.limiterEnabled ? 'Защита активна' : 'Включить защиту'}
        </button>
      </div>
    </div>
  );
};
