import React from 'react';
import { PRESETS } from '../constants/presets';
import { Preset, PresetId } from '../types/audio';
import { SlidersHorizontal, Sparkles } from 'lucide-react';

interface PresetsBarProps {
  currentPresetId: PresetId | null;
  onSelectPreset: (preset: Preset) => void;
  disabled?: boolean;
}

export const PresetsBar: React.FC<PresetsBarProps> = ({
  currentPresetId,
  onSelectPreset,
  disabled = false,
}) => {
  return (
    <div className="w-full bg-[#0b101c]/80 rounded-2xl border border-slate-800/80 p-3.5 backdrop-blur-md">
      <div className="flex items-center justify-between mb-2.5 px-1">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-sky-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Пресеты звучания
          </h3>
        </div>
        <span className="text-[11px] text-slate-400">
          Быстрое переключение профилей звука
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {PRESETS.map((preset) => {
          const isSelected = currentPresetId === preset.id;
          const isBuds = preset.id === 'buds_master';

          return (
            <button
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              disabled={disabled}
              className={`relative flex flex-col items-start p-2.5 rounded-xl border text-left transition-all ${
                isSelected
                  ? 'bg-gradient-to-b from-sky-500/20 to-purple-500/10 border-sky-400/60 shadow-[0_0_15px_rgba(56,189,248,0.2)] ring-1 ring-sky-400/40'
                  : 'bg-slate-900/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/50'
              } ${isBuds && !isSelected ? 'border-sky-500/30' : ''}`}
            >
              {isBuds && (
                <span className="absolute -top-1.5 -right-1 bg-gradient-to-r from-sky-500 to-indigo-500 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full uppercase shadow">
                  Buds4
                </span>
              )}

              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-base">{preset.icon}</span>
                <span className={`text-xs font-bold truncate ${isSelected ? 'text-sky-300' : 'text-slate-200'}`}>
                  {preset.nameRu}
                </span>
              </div>

              <span className="text-[10px] text-slate-400 line-clamp-2 leading-tight">
                {preset.description}
              </span>

              {isSelected && (
                <div className="mt-1.5 flex items-center gap-1 text-[10px] text-sky-400 font-medium">
                  <Sparkles className="w-2.5 h-2.5" />
                  <span>Активен</span>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
