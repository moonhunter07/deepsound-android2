export interface DSPSettings {
  subBass: number;      // 0 - 100 (Deep sub-bass 35-50Hz)
  bass: number;         // 0 - 100 (Punchy mid-bass 100-160Hz)
  clarity: number;      // 0 - 100 (Vocal presence 3.2kHz - 5kHz)
  treble: number;       // 0 - 100 (Air & sparkle 9kHz - 16kHz)
  stereoWidth: number;  // 0 - 100 (0=mono, 50=normal stereo, 100=wide 3D stage)
  spatial360: boolean;  // Virtual surround HRTF 360 audio for Galaxy Buds4 Pro
  loudness: number;     // 0 - 100 (Warm saturation pre-gain boost)
  limiterEnabled: boolean; // Brickwall Limiter to eliminate distortion / "хрип"
  bypass: boolean;      // A/B test (false = DSP active, true = bypass)
}

export type PresetId = 'buds_master' | 'deep_bass' | 'club' | 'clear' | 'neutral' | 'bass_monster' | 'custom';

export interface Preset {
  id: PresetId;
  name: string;
  nameRu: string;
  description: string;
  icon: string;
  settings: Omit<DSPSettings, 'bypass'>;
}

export interface AudioTrack {
  id: string;
  title: string;
  artist: string;
  duration: number; // in seconds
  url?: string;
  blob?: Blob;
  type: 'demo' | 'local';
  genre?: string;
  format?: string;
}

export interface BudsInfo {
  model: string;
  connected: boolean;
  codec: 'SSC' | 'LDAC' | 'AAC' | 'SBC';
  sampleRate: string;
  bitDepth: string;
  batteryLeft: number;
  batteryRight: number;
  batteryCase: number;
  ancMode: 'anc' | 'ambient' | 'off';
  spatial360: boolean;
  gamingMode: boolean;
}
